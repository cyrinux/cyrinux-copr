#!/bin/bash

set -ex # Print commands, exit on errors

# Here, we should maybe automatize a Windows build process later.

# See the "README.md" file of the current directory for Windows build
# instructions for now.
