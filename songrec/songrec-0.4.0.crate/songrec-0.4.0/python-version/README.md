This contains a partial, command-line only Python version of the current project, that was written before the primary version was rewritten in Rust for performance. Please see the [main `README.md` file](/README.md) for more information.

Dependencies are:

```
sudo apt install python3.6 python3-pip libportaudio2 ffmpeg
sudo pip3 install --upgrade numpy sounddevice pydub pytz requests
```
